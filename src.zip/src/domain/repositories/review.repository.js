// 📁 src/domain/repositories/review.repository.js
class ReviewRepository {
  async createReview(data) {}
  async getAllReviews() {}
  async getReviewById(id) {}
  async updateReviewById(id, data) {}
  async deleteReviewById(id) {}
}
module.exports = ReviewRepository;
